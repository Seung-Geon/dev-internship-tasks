---
name: new-view
description: 이 프로젝트의 컨벤션(script setup, XxxView.vue 네이밍, 라우터 등록, 필요시 Pinia store)을 따라 새 View를 스캐폴딩한다. "새 뷰 만들어줘", "/new-view <이름>" 등으로 트리거.
---

`$ARGUMENTS`로 전달된 이름(예: `Profile`)을 기준으로 새 View를 생성한다. 인자가 없으면 사용자에게 View 이름을 물어본다.

1. **파일 생성**: `src/views/<Name>View.vue`를 생성한다.
   - `<script setup>` 블록만 사용한다 (Options API 금지).
   - 필요한 반응형 상태/로직은 Composition API(`ref`, `computed` 등)로 작성한다.
   - 주요 블록에는 한국어 주석을 단다 (프로젝트 관례).
   - Vuetify 컴포넌트(`v-container`, `v-card` 등)를 사용해 기본 레이아웃을 잡는다.

2. **Store 필요 여부 확인**: 이 View가 자체 상태/API 호출을 필요로 하면 `src/stores/<name>.js`를 setup-style Pinia store로 생성한다:
   ```js
   export const use<Name>Store = defineStore('<name>', () => {
     // 상태와 함수
     return { ... }
   })
   ```
   필요하다면 `src/api/<name>Api.js`에 axios/firebase 호출 함수를 추가하고 store에서 사용한다.

3. **라우터 등록**: `src/router/index.js`의 `routes` 배열에 새 라우트를 추가한다. 기존 파일의 정적 import 스타일을 그대로 따른다 (lazy-loading이나 route guard가 없는 현재 패턴 유지).

4. 생성 후 `npm run dev`로 라우트가 정상적으로 뜨는지 사용자에게 확인을 요청한다.
