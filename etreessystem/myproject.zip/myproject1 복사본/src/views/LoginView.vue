<!-- =============================================
  LoginView.vue - 로그인 / 회원가입 페이지
  로그인 상태에 따라 다른 화면을 보여줍니다.
  - 로그인 전: 이메일/비밀번호 입력 폼
  - 로그인 후: 환영 메시지와 로그아웃 버튼
============================================= -->

<template>
<h1>로그인 페이지입니다</h1>

<!-- 로그인이 안 된 상태: 입력 폼 표시 -->
<div v-if="!authStore.user">
    <input v-model="authStore.loginInfo.email" type="email" placeholder="이메일 입력"/>
    | <input v-model="authStore.loginInfo.password" type="password" placeholder="비밀번호 입력"/>
     <button @click="login">로그인</button>
    | <button @click="register">회원가입</button>
</div>

<!-- 로그인된 상태: 환영 메시지와 로그아웃 버튼 -->
<div v-else>
    <p>환영합니다, {{ authStore.user.email }}님!</p>
    <button @click="logoutUser">로그아웃</button>
</div>

</template>

<script setup>
import { ref, onMounted } from "vue"
import { useAuthStore } from '../stores/auth'
import { useRouter } from 'vue-router'

// 로그인 상태 저장소 사용
const authStore = useAuthStore()
// 페이지 이동을 위한 라우터
const router = useRouter()

// 회원가입 버튼 클릭 시 실행
const register = async () => {
    try {
        await authStore.registerUser(authStore.loginInfo.email, authStore.loginInfo.password)
        alert('회원가입 성공!')
    } catch (error) {
        alert('회원가입 실패: ' + error.message)
    }
}

// 로그인 버튼 클릭 시 실행
const login = async () => {
    try {
        await authStore.loginUser(authStore.loginInfo.email, authStore.loginInfo.password)
        alert('로그인 성공!')
        router.push('/chat')  // 로그인 성공 후 채팅 페이지로 이동
    } catch (error) {
        alert('로그인 실패: ' + error.message)
    }
}

// 로그아웃 버튼 클릭 시 실행
const logoutUser = async () => {
    try {
        await authStore.logoutAuth()
        alert('로그아웃 성공!')
    } catch (error) {
        alert('로그아웃 실패: ' + error.message)
    }
}
</script>
