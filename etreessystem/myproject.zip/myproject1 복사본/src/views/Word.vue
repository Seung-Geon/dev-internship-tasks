<!-- =============================================
  Word.vue - 영어 단어장 페이지
  영어 단어를 입력하면 뜻(정의)과 예문을 조회합니다.
  Wordnik API를 사용합니다.
============================================= -->

<script setup>
import { ref } from 'vue'
import { useWordStore } from '../stores/word'

const wordStore = useWordStore()

// 단어 입력창 DOM 요소 (빈 입력 시 포커스 이동에 사용)
const wordFocus = ref(null)

// 단어 정의(뜻) 조회 버튼 클릭 시 실행
const getWordDefinition = async () => {
    // 단어가 비어있으면 경고하고 입력창에 커서 이동
    if (wordStore.word.word == '') {
        alert('단어를 입력하세요.')
        wordFocus.value.focus()
        return
    }
    await wordStore.getWordDefinition(wordStore.word.word)

    // 결과가 없으면 안내 메시지 표시
    if (wordStore.word.definitions.length == 0) {
        wordStore.word.definitions = [{ text: '단어 정의를 찾을 수 없습니다.' }]
    }
}

// 단어 예문 조회 버튼 클릭 시 실행
const getWordExamples = async () => {
    if (wordStore.word.word == '') {
        alert('단어를 입력하세요.')
        wordFocus.value.focus()
        return
    }
    await wordStore.getWordExamples(wordStore.word.word)

    // 결과가 없으면 안내 메시지 표시
    if (wordStore.word.definitions.length == 0) {
        wordStore.word.definitions = [{ text: '단어 예시를 찾을 수 없습니다.' }]
    }
}
</script>

<template>
  <h1>단어장</h1>
  <p>단어장 페이지입니다.</p>

  <!-- 단어 입력창: Enter 키로도 정의 조회 가능 -->
  word : <input ref="wordFocus" v-model="wordStore.word.word" placeholder="단어를 입력하세요." @keyup.enter="getWordDefinition"/> |
  <button @click="getWordDefinition">단어 정의 조회</button> |
  <button @click="getWordExamples">단어 예시 조회</button>

  <!-- 조회 결과 테이블 (결과가 있을 때만 표시) -->
  <v-card v-if="wordStore.word.definitions.length > 0" class="mt-4">
    <v-table border="1" cellpadding="5" cellspacing="0">
      <thead>
        <tr>
          <th>순번</th>
          <th>내용</th>
        </tr>
      </thead>
      <tbody>
        <!-- 각 정의/예문을 순번과 함께 출력 -->
        <tr v-for="(def, index) in wordStore.word.definitions" :key="index">
          <td>{{ index + 1 }}</td>
          <td>{{ def.text }}</td>
        </tr>
      </tbody>
    </v-table>
  </v-card>
</template>
