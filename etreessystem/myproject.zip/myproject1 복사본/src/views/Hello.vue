<!-- =============================================
  Hello.vue - 홈(테스트) 페이지
  Vue의 다양한 기능을 테스트하는 화면입니다.
  - v-if/v-else-if/v-else 조건부 렌더링 테스트
  - 외부 API 데이터 호출 및 테이블 표시
  - 테이블 행 선택/수정/삭제 기능
============================================= -->

<script setup>
import { ref, reactive } from 'vue'
import BasicTable from '../components/BasicTable.vue';  // 재사용 테이블 컴포넌트
import axios from 'axios';
import { useUserStore } from '../stores/user';

// v-if 테스트용 반응형 객체
const testObj = reactive({
    email: 'John@example.com',
    age: 30
});

// 테이블에 표시할 데이터 (header: 컬럼명, rows: 실제 데이터)
const gridData = ref({
    header: ['name', 'city'],
    rows: [
        { id: 1, name: 'John', city: 'New York' },
        { id: 2, name: 'Jane', city: 'Los Angeles' },
        { id: 3, name: 'Doe', city: 'Chicago' },
    ]
})

// 외부 API에서 실제 유저 데이터를 가져와 테이블에 표시하는 함수
const dataCall = () => {
    console.log('데이터 호출');
    axios.get('https://jsonplaceholder.typicode.com/users')
        .then(response => {
            console.log(response.data);
            // API 데이터를 테이블 형식에 맞게 변환 (id, name, city만 추출)
            gridData.value.rows = response.data.map(user => ({
                id: user.id,
                name: user.name,
                city: user.address.city
            }));
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
}

// v-if 조건부 렌더링 테스트용 반응형 객체
const seen = reactive({ test: 'test' });

// 할일 목록 (v-for 반복 렌더링 테스트)
const todos = ref([
    { id: 1, text: 'Learn JavaScript' },
    { id: 2, text: 'Learn Vue' },
    { id: 3, text: 'Build something awesome' }
]);

// 할일 목록에 항목 추가 테스트 함수
const dataChange = () => {
    console.log('데이터 변경');
    todos.value = [
        ...todos.value,
        { id: 4, text: 'Learn React' }
    ];
}

// 전역 유저 저장소 (다른 컴포넌트와 데이터 공유 테스트)
const user = useUserStore();

// 테이블 행 클릭 시 실행: 선택된 행의 데이터를 유저 저장소에 저장
const onSelect = (row) => {
    console.log('Selected row:', row);
    user.id = row.id;
    user.name = row.name;
    user.city = row.city;
    console.log('Selected user:', user);
}

// 특정 행의 데이터를 수정하는 함수
// user: 수정할 데이터 (id로 기존 행을 찾아서 교체)
const onEdit = (user) => {
    console.log('데이터 수정');
    const index = gridData.value.rows.findIndex(row => row.id === user.id)
    if (index !== -1) {
        gridData.value.rows[index] = user  // 해당 인덱스의 행 데이터 교체
    }
}

// 선택된 행들을 체크박스 배열 (현재 BasicTable 컴포넌트에 전달)
const selected = ref([]);

// 체크박스로 선택된 행들을 삭제하는 함수
const onRemove = () => {
    console.log('데이터 삭제');
    // selected가 true인 행만 필터링해서 제거
    gridData.value.rows = gridData.value.rows.filter(row => !row.selected);
}
</script>

<template>
  <h1>Hello Vue Router</h1>

  <!-- v-if / v-else-if / v-else 조건부 렌더링 테스트 -->
  <p v-if="seen.test=='test1'">if가 보입니다 </p>
  <p v-else-if="seen.test=='test2'">else-if가 보입니다</p>
  <p v-else>else가 보입니다</p>

  <!-- seen.test 값 변경 입력창 (값에 따라 위 문구가 바뀜) -->
  <v-text-field v-model="seen.test" placeholder="Enter something" />
  <v-text-field v-model="testObj.email" placeholder="Enter email" />
  <v-text-field v-model="testObj.age" placeholder="Enter age" />

  <!-- 버튼 클릭으로 데이터 조작 테스트 -->
  <v-btn @click="dataCall">데이터호출</v-btn>
  <v-btn @click="dataChange">데이터 변경</v-btn>

  <!-- v-for 반복 렌더링: 할일 목록 -->
  <ol>
    <li v-for="todo in todos" :key="todo.id">
      {{ todo.text }}
    </li>
  </ol>

  <!-- 새 행 등록/수정 입력 폼 -->
  <p>
    name: <v-text-field v-model="user.name" placeholder="Enter name" />
    city: <v-text-field v-model="user.city" placeholder="Enter city" />
    <!-- 등록: 현재 입력한 name, city로 새 행 추가 -->
    <v-btn @click="() => gridData.rows.push({ id: gridData.rows.length + 1, name: user.name, city: user.city })">등록</v-btn>
    <!-- 수정: 선택된 행의 데이터를 현재 입력값으로 변경 -->
    <v-btn @click="() => onEdit(user)">수정</v-btn>
  </p>

  <!-- 재사용 테이블 컴포넌트에 데이터와 이벤트 핸들러 전달 -->
  <BasicTable :gridData="gridData" :onSelect="onSelect" :selected="selected" :onRemove="onRemove"/>
</template>

<style scoped>
.read-the-docs {
  color: #888;
}
</style>
