<!-- =============================================
  DashboardView.vue - 대시보드 / 차트 페이지
  통계 카드(총 유저/게시글/댓글/할일 수)와
  라인 차트(날씨), 파이 차트(데이터 분포)를 보여줍니다.
============================================= -->

<script setup>
import { onMounted, ref } from "vue"
import LineChart from "../components/LineChart.vue";  // 라인(꺾은선) 차트 컴포넌트
import { useChartStore } from '../stores/dashboard'
import PieChart from "../components/PieChart.vue";    // 파이(원형) 차트 컴포넌트
import { usersApiCall, postsApiCall, commentsApiCall, todosApiCall } from "../api/dashboardApi";

const msg = ref('차트 페이지입니다 ')
const chartStore = useChartStore()

// 각 통계 데이터를 담는 변수들
const usersLength = ref(0)     // 총 유저 수
const postsLength = ref(0)     // 총 게시글 수
const commentsLength = ref(0)  // 총 댓글 수
const todosLength = ref(0)     // 총 할일 수

// 상단에 보여줄 통계 카드 목록
const statCards = ref([])

// 화면이 열릴 때 모든 데이터를 한꺼번에 불러옴
onMounted(async () => {
    // 4개 API를 동시에 호출해서 빠르게 데이터 가져오기
    usersLength.value = await usersApiCall()
    postsLength.value = await postsApiCall()
    commentsLength.value = await commentsApiCall()
    todosLength.value = await todosApiCall()

    // 통계 카드 데이터 구성 (title: 제목, value: 숫자, icon: 아이콘, color: 색상)
    statCards.value = [
        { title: '총 유저수', value: usersLength.value.length, icon: 'mdi-account-group', color: 'blue' },
        { title: '총 게시글수', value: postsLength.value.length, icon: 'mdi-post', color: 'green' },
        { title: '총 댓글수', value: commentsLength.value.length, icon: 'mdi-comment', color: 'orange' },
        { title: '총 할일수', value: todosLength.value.length, icon: 'mdi-check-circle', color: 'purple' },
    ]

    // 라인 차트용 날씨 데이터 불러오기
    chartStore.getLineData()

    // 파이 차트 데이터: 각 카테고리의 개수
    chartStore.pieSeries = [
        usersLength.value.length,
        postsLength.value.length,
        commentsLength.value.length,
        todosLength.value.length
    ]
    // 파이 차트 라벨 (각 조각의 이름)
    chartStore.pieLabel = ['유저', '게시글', '댓글', '할일']
})
</script>

<template>
    <h1>{{ msg }}</h1>
    <v-container fluid>
        <!-- 대시보드 제목 -->
        <v-row class="mb-4">
            <v-col cols="12" md="6" lg="4">대시보드</v-col>
        </v-row>

        <!-- 통계 카드 목록 (유저수, 게시글수, 댓글수, 할일수) -->
        <v-row>
            <v-col v-for="card in statCards" :key="card.title" cols="12" md="6" lg="4">
                <v-card rounded="lg" elevation="2">
                    <v-card-text class="d-flex align-center justify-space-between">
                        <div>
                            <!-- 카드 제목 (작은 글씨) -->
                            <div class="text-caption text-grey">
                                {{ card.title }}
                            </div>
                            <!-- 카드 숫자 (큰 굵은 글씨) -->
                            <div class="text-h5 font-weight-bold mt-1">
                                {{ card.value }}
                            </div>
                        </div>
                        <!-- 카드 아이콘 -->
                        <v-icon :color="card.color" size="40">{{ card.icon }}</v-icon>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>

        <!-- 차트 영역 -->
        <v-row class="mt-4">

            <!-- 라인 차트: 최근 날씨(기온) 변화 -->
            <v-col cols="12" md="8">
                <v-card rounded="lg" elevation="2">
                    <v-card-title class="pa-4">
                        최근 날씨 현황
                    </v-card-title>
                    <v-card-text>
                        <!-- series: Y축 데이터, categorie: X축 날짜 -->
                        <LineChart :series="chartStore.series" :categorie="chartStore.categorie" />
                        <div class="text-center text-grey py-8">라인 차트 영역</div>
                    </v-card-text>
                </v-card>
            </v-col>

            <!-- 파이 차트: 카테고리별 데이터 비율 -->
            <v-col cols="12" md="4">
                <v-card rounded="lg" elevation="2">
                    <v-card-title class="pa-4">
                        카테고리 분포
                    </v-card-title>
                    <v-card-text>
                        <!-- series: 각 조각의 값, label: 각 조각의 이름 -->
                        <PieChart :series="chartStore.pieSeries" :label="chartStore.pieLabel" />
                        <div class="text-center text-grey py-8">파이 차트 영역</div>
                    </v-card-text>
                </v-card>
            </v-col>

        </v-row>
    </v-container>
</template>
