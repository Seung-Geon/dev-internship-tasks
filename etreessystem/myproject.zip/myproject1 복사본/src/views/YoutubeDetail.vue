<!-- =============================================
  YoutubeDetail.vue - 유튜브 영상 상세 페이지
  URL에서 videoId를 읽어서 해당 영상의 상세 정보를 보여줍니다.
  영상을 직접 재생할 수 있는 플레이어도 포함합니다.
============================================= -->

<script setup>
import { ref, defineProps, onMounted } from 'vue'
import { useYoutubeStore } from '../stores/youtube'
import { useRoute } from 'vue-router'

const youtubeStore = useYoutubeStore()

// 현재 URL 정보를 가져옴 (URL 파라미터 읽기에 사용)
const route = useRoute()

// URL에서 videoId 추출 (예: /youtube/dQw4w9WgXcQ → videoId = 'dQw4w9WgXcQ')
const { videoId } = route.params

// 영상 상세 데이터를 저장할 변수 (처음엔 null, API 호출 후 채워짐)
const videoDetails = ref(null)

// 화면이 열릴 때 videoId로 영상 상세 정보 불러오기
onMounted(async () => {
  if (videoId) {
    videoDetails.value = await youtubeStore.getYoutubeVideoDetails(videoId)
  }
})
</script>

<template>
  <h1>유튜브 영상 상세</h1>

  <!-- 영상 데이터가 로드된 경우에만 표시 -->
  <div v-if="videoDetails">
      <!-- 영상 제목 -->
      <h2>{{ videoDetails.snippet.title }}</h2>

      <!-- 유튜브 영상 플레이어 (iframe으로 직접 재생) -->
      <iframe
          :src="'https://www.youtube.com/embed/' + videoDetails.id"
          width="100%"
          height="500"
          allowfullscreen
      ></iframe>

      <!-- 통계 정보 -->
      <p>조회수: {{ videoDetails.statistics.viewCount }}</p>
      <p>좋아요: {{ videoDetails.statistics.likeCount }}</p>

      <!-- 영상 설명 -->
      <p>{{ videoDetails.snippet.description }}</p>
  </div>
</template>
