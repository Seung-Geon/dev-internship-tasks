<!-- =============================================
  Weather.vue - 날씨 페이지
  도시를 선택하면 해당 도시의 현재 날씨를 보여줍니다.
  온도, 습도, 날씨 상태, 풍속 정보를 표시합니다.
============================================= -->

<script setup>
import { onMounted, ref } from 'vue'
import { useWeatherStore } from '../stores/weather'

const weatherStore = useWeatherStore()

// 현재 선택된 도시 (드롭다운에서 선택한 값)
const selectedCity = ref(null)

// 화면에 표시할 날씨 데이터
const weather = ref(null)

// 선택 가능한 한국 주요 도시 목록
// label: 화면에 표시될 한글 이름, value: API 요청에 사용할 영문 이름
const cities = ref([
  { label: '서울', value: 'Seoul' },
  { label: '부산', value: 'Busan' },
  { label: '인천', value: 'Incheon' },
  { label: '대구', value: 'Daegu' },
  { label: '대전', value: 'Daejeon' },
  { label: '광주', value: 'Gwangju' },
  { label: '수원', value: 'Suwon' },
  { label: '제주', value: 'Jeju' },
])

// 화면이 열릴 때 기본값으로 서울 날씨 불러오기
onMounted(() => {
  selectedCity.value = cities.value[0].value  // 기본 도시: 서울
  onCityChange('Seoul')
})

// 도시 선택이 바뀔 때마다 날씨 데이터 업데이트
// selected: 선택된 도시 영문 이름
const onCityChange = async (selected) => {
  await weatherStore.getWeather(selected)   // 날씨 API 호출
  weather.value = weatherStore.weather      // 받아온 날씨 데이터 저장
}
</script>

<template>
  <div>
    <h2>날씨</h2>

    <!-- 도시 선택 드롭다운 -->
    <v-select
        v-model="selectedCity"
        :items="cities"
        item-title="label"
        item-value="value"
        label="도시 선택"
        @update:modelValue="onCityChange(selectedCity)"
    />

    <!-- API 요청 중일 때 로딩 표시 -->
    <div v-if="weatherStore.isLoading">로딩중...</div>

    <!-- 에러가 있을 때 에러 메시지 표시 -->
    <v-alert v-else-if="weatherStore.errorMsg" type="error">
      {{ weatherStore.errorMsg }}
    </v-alert>

    <!-- 날씨 데이터가 있을 때 날씨 정보 표시 -->
    <div v-else-if="weather">
      <!-- 날씨 아이콘 이미지 -->
      <img
        v-if="weather"
        :src="`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`"
        :alt="weather.weather[0].description"
      />
      <p>🌡️ 온도: {{ weather?.main.temp }}°C</p>
      <p>💧 습도: {{ weather?.main.humidity }}%</p>
      <p>🌤️ 날씨: {{ weather?.weather[0].description }}</p>
      <p>💨 풍속: {{ weather?.wind.speed }}m/s</p>
    </div>
  </div>
</template>
