<!-- =============================================
  Board.vue - 게시판 페이지
  외부 API에서 댓글 목록을 가져와 테이블로 보여줍니다.
  페이지가 열릴 때 자동으로 목록을 불러옵니다.
============================================= -->

<script setup>
import { ref, reactive, onMounted } from 'vue'
import BasicTable from '../components/BasicTable.vue';  // 테이블 컴포넌트
import { useBoardStore } from '../stores/board';

// 게시판 데이터 저장소
const boardStore = useBoardStore();

// 테이블에 표시할 게시판 목록 데이터
const boardList = ref(boardStore.boardList);

// 게시판 목록을 새로 불러오는 함수
const getBoardList = () => {
    boardStore.getBoardList();
}

// 화면이 처음 열릴 때 자동으로 목록 불러오기
onMounted(() => {
    getBoardList();
})
</script>

<template>
    <h1>게시판</h1>
    <!-- 새로고침 버튼 -->
    <v-btn @click="getBoardList">게시판 목록 가져오기</v-btn>
    <!-- 게시판 데이터를 BasicTable 컴포넌트에 전달 -->
    <BasicTable :gridData="boardList" />
</template>
