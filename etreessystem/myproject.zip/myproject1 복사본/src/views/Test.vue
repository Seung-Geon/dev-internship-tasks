<script setup>

import { onMounted, reactive ,ref} from 'vue';
import axios from 'axios';

const msg = reactive({
    text: 'Vue Js Test!!!'
})

const userInput = reactive({
    name: '',
    email:''
})

const users = reactive([])


onMounted(()=>{
    
    const axiosData = async ()=>{
        const axiosCall = await axios.get('https://jsonplaceholder.typicode.com/users')
        axiosCall.data.map((user)=> users.push(user))
    }
    axiosData()
})

const todos = reactive([
    { id: 1, title: 'Buy groceries', completed: false },
    { id: 2, title: 'Finish Vue.js project', completed: true },
    { id: 3, title: 'Read a book', completed: false }
])

const nextId = ref(4)

const addUser = () => {
    const newUser = {
        id: nextId.value + 1,
        name: userInput.name,
        email : userInput.email
    }
    users.push(newUser)
}

const SelectUser = (user)=>{

    const index = users.findIndex((u)=> u.id === user.id)
    userInput.id = user.id
    userInput.name = user.name
    userInput.email = user.email
}

const EditUser = ()=>{
    const index = users.findIndex((u)=> u.id === userInput.id)
    users[index].name = userInput.name
    users[index].email = userInput.email    
    userInput.name = ''
    userInput.email = ''
}

const searchInput = ref('Leanne Graham')

const searchCall = async ()=>{
    const axiosCall = await axios.get('https://jsonplaceholder.typicode.com/users'
        ,{params:{name:searchInput.value}}
    )

    console.log(axiosCall.data)
}
</script>

<template>

    <h1>Test Vue JS</h1>
    <p>{{ msg.text }}</p>
    <p>
        name : <input v-model="userInput.name" placeholder="Name"/>
        email : <input v-model="userInput.email" placeholder="Email"/>
        | <button @click="addUser">추가</button>
        | <button @click="EditUser">수정</button>
    </p>
    <p>
        name : <input v-model="searchInput" placeholder="검색"/>
        <button @click = "searchCall">검색</button>
    </p>
    <ul>
        <li v-for="user in users" :key="user.id">
            <div @click = "SelectUser(user)">{{ user.name }} </div> - {{ user.email }}
        </li>
    </ul>
    <li v-for = "todo in todos" :key="todo.id">
        {{ todo.title }} - {{ todo.completed ? 'Completed' : 'Pending' }}
    </li>

</template>