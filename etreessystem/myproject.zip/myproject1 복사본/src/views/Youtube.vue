<!-- =============================================
  Youtube.vue - 유튜브 검색 페이지
  검색어를 입력하면 관련 유튜브 영상 목록을 보여줍니다.
  영상을 클릭하면 상세 페이지로 이동합니다.
============================================= -->

<script setup>
import { ref, onMounted } from 'vue'
import { useYoutubeStore } from '../stores/youtube'
import YoutubeCard from '../components/YoutubeCard.vue'  // 영상 카드 컴포넌트

const youtubeStore = useYoutubeStore()

// 검색 버튼 클릭 또는 Enter 키 입력 시 실행
const searchVideos = () => {
    // 검색어가 비어있으면 경고
    if (youtubeStore.searchQuery.trim() === '') {
        alert('검색어를 입력하세요.')
        return
    }
    youtubeStore.clearVideos()                               // 이전 검색 결과 초기화
    youtubeStore.getYoutubeVideos(youtubeStore.searchQuery)  // 새 검색 실행
}
</script>

<template>
  <h1>유튜브 검색</h1>

  <!-- 검색어 입력창 (Enter 키로도 검색 가능) -->
  <v-text-field
    v-model="youtubeStore.searchQuery"
    label="검색어를 입력하세요."
    @keyup.enter="searchVideos"
  />
  <v-btn @click="searchVideos">검색</v-btn>

  <!-- 검색 결과가 있을 때 영상 목록 표시 -->
  <div v-if="youtubeStore.videos.length > 0" class="mt-4">
    <h2>검색 결과</h2>
    <!-- 3열 그리드로 영상 카드 배치 (화면 크기에 따라 반응형) -->
    <v-row>
      <v-col
        v-for="video in youtubeStore.videos"
        :key="video.id.videoId"
        cols="12" md="6" lg="4"
      >
        <!-- 각 영상을 YoutubeCard 컴포넌트에 전달 -->
        <YoutubeCard :video="video" />
      </v-col>
    </v-row>
  </div>
</template>
