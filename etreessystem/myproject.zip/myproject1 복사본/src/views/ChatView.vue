<!-- =============================================
  ChatView.vue - 채팅 메인 페이지
  상대방 이메일을 입력해서 1:1 채팅을 시작합니다.
  로그인이 필요하며, 로그인 안 된 경우 로그인 페이지로 이동합니다.
============================================= -->

<script setup>
import { ref, onMounted } from "vue"
import { useAuthStore } from '../stores/auth'
import { useRouter } from 'vue-router'
import { findOrCreateChatRoom } from '../api/chatApi'
import { getUserByEmail } from '../api/authApi'

// 페이지 안내 메시지
const msg = ref('채팅 페이지 입니다 ')

// 채팅을 시작할 상대방 이메일 입력값
const newChatEmail = ref('')

const authStore = useAuthStore();
const router = useRouter();

// 화면이 열릴 때 로그인 여부 확인
onMounted(() => {
    if (!authStore.user) {
        alert('로그인이 필요합니다!')
        router.push('/login')  // 로그인 안 됐으면 로그인 페이지로 강제 이동
    }
})

// 채팅 시작 버튼 클릭 시 실행
// 상대방 이메일로 유저를 찾고, 채팅방을 생성(또는 기존 채팅방 찾기)한 뒤 입장합니다.
const startChat = async () => {
    // 이메일 미입력 시 경고
    if (newChatEmail.value.trim() === '') {
        alert('상대방 이메일을 입력해주세요!')
        return
    }

    try {
        // 입력한 이메일로 유저 존재 여부 확인
        const otherUid = await getUserByEmail(newChatEmail.value)
        if (!otherUid) {
            alert('해당 이메일을 가진 사용자가 없습니다!')
            return
        }

        // 두 사람의 채팅방을 찾거나 새로 만든다
        const chatRoomId = await findOrCreateChatRoom(authStore.user.email, newChatEmail.value)

        // 채팅방으로 이동 (상대방 이메일을 URL 파라미터로 함께 전달)
        router.push({ path: `/chat/${chatRoomId.id}`, query: { otherUserId: newChatEmail.value } })
    } catch (error) {
        console.error('채팅방 생성 실패:', error)
        alert('채팅방 생성에 실패했습니다. 다시 시도해주세요.')
    }
}
</script>

<template>
<h1>{{ msg }}</h1>

<!-- 로그인된 경우에만 채팅 시작 폼 표시 -->
<div v-if="authStore.user">
    <p>{{ authStore.user.email }}님</p>
    <v-card-title>새 채팅 시작</v-card-title>
    <!-- 상대방 이메일 입력 -->
    <v-text-field v-model="newChatEmail" label="상대방 이메일" />
    <v-btn @click="startChat">채팅 시작</v-btn>
</div>
</template>
