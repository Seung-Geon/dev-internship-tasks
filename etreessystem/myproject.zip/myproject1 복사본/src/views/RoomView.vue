<!-- =============================================
  RoomView.vue - 채팅방 페이지
  특정 채팅방의 실시간 메시지를 보여주고 메시지를 보낼 수 있습니다.
  내가 보낸 메시지는 오른쪽(파란색), 상대방 메시지는 왼쪽(회색)으로 표시됩니다.
============================================= -->

<script setup>
import { ref, reactive, nextTick, onMounted, onUnmounted, watch } from "vue"
import { useAuthStore } from '../stores/auth'
import { useRouter } from 'vue-router'
import { useChatStore } from '../stores/chat'

const authStore = useAuthStore();
const chatStore = useChatStore();
const router = useRouter();

// 실시간 구독을 해제하기 위한 함수 (화면을 떠날 때 호출)
let unsubscribe = null

// URL 파라미터에서 채팅 상대 이메일과 채팅방 ID 가져오기
const otherUserId = router.currentRoute.value.query.otherUserId
const chatRoomId = ref('')
chatRoomId.value = router.currentRoute.value.params.chatRoomId

// 메시지 입력창의 현재 텍스트
const text = ref('')

// 채팅 메시지 영역 DOM 요소 (스크롤 제어에 사용)
const chatContainer = ref(null)

// 메시지 전송 중 중복 전송 방지 플래그
const isSending = ref(false)

// 채팅창 스크롤을 맨 아래로 내리는 함수
// nextTick: DOM 업데이트 완료 후 실행되도록 보장
const scrollToBottom = async () => {
    await nextTick()
    if (chatContainer.value) {
        const container = chatContainer.value.$el
        container.scrollTop = container.scrollHeight  // 스크롤을 맨 아래로
    }
}

// 화면이 열릴 때: 채팅방 메시지 실시간 구독 시작
onMounted(async () => {
    unsubscribe = chatStore.subscribeToMessages(chatRoomId.value)
    await scrollToBottom()
})

// 화면을 떠날 때: 실시간 구독 해제 (메모리 낭비 방지)
onUnmounted(() => {
    if (unsubscribe) {
        unsubscribe()
    }
})

// 새 메시지가 도착할 때마다 자동으로 스크롤을 맨 아래로 내림
watch(() => chatStore.messages, async () => {
    await scrollToBottom()
}, { deep: true })

// 메시지 전송 함수
const sendMessage = async () => {
    if (isSending.value) return  // 이미 전송 중이면 중복 전송 방지

    // 빈 메시지 방지
    if (text.value.trim() === '') {
        alert('메시지를 입력해주세요!')
        return
    }

    isSending.value = true  // 전송 시작
    try {
        await chatStore.sendMessageStore(
            chatRoomId.value,
            authStore.user.uid,
            authStore.user.email,
            text.value
        )
        text.value = ''  // 전송 후 입력창 초기화
    } catch (error) {
        console.error('메시지 전송 실패:', error)
        alert('메시지 전송에 실패했습니다. 다시 시도해주세요.')
    } finally {
        isSending.value = false  // 전송 완료 (성공/실패 모두 해제)
    }
}
</script>

<template>
  <h1>채팅방 페이지입니다</h1>
  <h2>채팅 상대: {{ otherUserId }}</h2>

  <!-- 메시지 목록 영역 (스크롤 가능, 높이 400px 고정) -->
  <v-sheet height="400px" class="overflow-auto pa-4" ref="chatContainer">
    <div
        v-for="message in chatStore.messages"
        :key="message.messageId"
        class="d-flex mb-3"
        :class="message.uid === authStore.user.uid ? 'justify-end' : 'justify-start'"
    >
        <!-- 말풍선: 내 메시지(오른쪽, 파란색) vs 상대방 메시지(왼쪽, 회색) -->
        <div
            class="pa-3 rounded-lg"
            style="max-width: 60%"
            :style="message.uid === authStore.user.uid
                ? 'background-color: #4F6EF7; color: white; border-radius: 16px 16px 0px 16px'
                : 'background-color: #f1f1f1; color: black; border-radius: 16px 16px 16px 0px'"
        >
            <!-- 상대방 메시지일 때만 이름(이메일) 표시 -->
            <div v-if="message.uid !== authStore.user.uid"
                style="font-size: 11px; color: gray; margin-bottom: 4px">
                {{ message.email }}
            </div>

            <!-- 메시지 본문 -->
            <div>{{ message.text }}</div>

            <!-- 메시지 전송 시각 (HH:MM 형식) -->
            <div style="font-size: 10px; opacity: 0.7; text-align: right; margin-top: 4px">
                {{ new Date(message.createdAt?.toDate()).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }) }}
            </div>
        </div>
    </div>
  </v-sheet>

  <!-- 메시지 입력창 (Enter 키로도 전송 가능) -->
  <v-text-field v-model="text" label="메시지를 입력하세요" @keydown.enter.prevent="sendMessage"/>
  <v-btn @click="sendMessage">전송</v-btn>
</template>
