// =============================================
// firebase.js - Firebase(구글 서버) 연결 설정
// Firebase는 구글이 제공하는 서버 서비스로,
// 데이터베이스(Firestore)와 로그인(Auth) 기능을 사용합니다.
// =============================================

import { initializeApp } from "firebase/app";       // Firebase 앱 초기화 함수
import { getAnalytics } from "firebase/analytics";  // 앱 사용 통계 기능
import { getFirestore, initializeFirestore } from "firebase/firestore"; // 데이터베이스 기능
import { getAuth } from 'firebase/auth';             // 로그인/회원가입 기능

// 이 프로젝트의 Firebase 연결 정보 (Firebase 콘솔에서 발급받은 고유 키)
const firebaseConfig = {
  apiKey: "AIzaSyDTXVqy9OtIibW_GXUdM7n90-p24kDC0sA",
  authDomain: "chatexample-b3e63.firebaseapp.com",
  projectId: "chatexample-b3e63",
  storageBucket: "chatexample-b3e63.firebasestorage.app",
  messagingSenderId: "805962299727",
  appId: "1:805962299727:web:fe3e605bdbb6a14c856d3a",
  measurementId: "G-C95KZW63Z6"
};

// Firebase 앱 초기화 (연결 시작)
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app); // 분석 기능 활성화

// db: Firestore 데이터베이스 인스턴스 (채팅, 유저 정보 저장에 사용)
// experimentalForceLongPolling: 사파리 브라우저에서도 실시간 기능이 작동하도록 설정
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true  // ✅ 사파리 호환성 해결
})

// auth: 로그인/회원가입 인증 인스턴스
export const auth = getAuth(app);
