// =============================================
// api/wordApi.js - 영어 단어 사전 API
// Wordnik API를 사용하여 영어 단어의
// 정의(뜻)와 예문을 가져옵니다.
// API 키는 환경변수(.env 파일)에서 불러옵니다.
// =============================================

const apikey = import.meta.env.VITE_WORDNIK_API_KEY  // .env 파일의 Wordnik API 키
const baseUrl = 'https://api.wordnik.com/v4'          // Wordnik API 기본 URL

// 단어 정의(뜻) 조회 함수
// word: 검색할 영어 단어 (예: 'apple')
// limit=200: 최대 200개의 정의를 가져옴
// sourceDictionaries=all: 모든 사전에서 검색
export const fetchWordDefinition = async (word) => {
  const response = await fetch(
    `${baseUrl}/word.json/${word}/definitions?limit=200&includeRelated=false&sourceDictionaries=all&useCanonical=false&includeTags=false&api_key=${apikey}`
  )
  const data = await response.json()
  return data
}

// 단어 예문 조회 함수
// word: 검색할 영어 단어
// limit=5: 최대 5개의 예문을 가져옴
export const fetchWordExamples = async (word) => {
  const response = await fetch(
    `${baseUrl}/word.json/${word}/examples?limit=5&includeDuplicates=false&useCanonical=false&skip=0&api_key=${apikey}`
  )
  const data = await response.json()
  return data
}
