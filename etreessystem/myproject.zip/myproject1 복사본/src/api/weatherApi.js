// =============================================
// api/weatherApi.js - 날씨 정보 API
// OpenWeatherMap API를 사용하여 특정 도시의
// 현재 날씨 정보를 가져옵니다.
// API 키는 환경변수(.env 파일)에서 불러옵니다.
// =============================================

const API_KEY = import.meta.env.VITE_WEATHER_API_KEY  // .env 파일의 날씨 API 키
const BASE_URL = 'https://api.openweathermap.org/data/2.5'  // OpenWeatherMap 기본 URL

// 도시 이름으로 현재 날씨를 가져오는 함수
// word: 도시 영문명 (예: 'Seoul', 'Busan')
// units=metric: 섭씨(°C) 단위 사용
// lang=kr: 날씨 설명을 한국어로 반환
export const fetchSeoulWeather = async (word) => {
  const response = await fetch(
    `${BASE_URL}/weather?q=${word}&appid=${API_KEY}&units=metric&lang=kr`
  )
  const data = await response.json()
  return data
}
