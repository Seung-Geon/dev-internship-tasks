// =============================================
// api/chatApi.js - 채팅 관련 API
// Firebase Firestore를 사용하여
// 메시지 전송, 실시간 메시지 수신, 채팅방 관리 기능을 제공합니다.
// =============================================

import { collection, addDoc, onSnapshot, orderBy, query, getDocs, where } from 'firebase/firestore'
import { db } from '../firebase'

// 메시지 전송 함수
// message: { chatRoomId(채팅방 ID), text(내용), uid(보낸사람 ID), email(보낸사람 이메일), createdAt(시각) }
export const sendMessage = async (message) => {
    try {
        // 저장할 메시지 데이터 구성
        const messageData = {
            text: message.text,       // 메시지 내용
            uid: message.uid,         // 보낸 사람 고유 ID
            createdAt: message.createdAt, // 보낸 시각
            readAt: null,             // 읽은 시각 (아직 안 읽었으면 null)
        }

        // Firestore: chatRooms > [채팅방ID] > messages 경로에 메시지 문서 추가
        await addDoc(collection(db, 'chatRooms', message.chatRoomId, 'messages'), messageData)
    } catch (error) {
        console.error('Error sending message: ', error)
    }
}

// 전체 메시지 실시간 구독 함수 (현재 미사용)
// callback: 메시지가 바뀔 때마다 호출될 함수
// 반환값: 구독을 해제할 때 호출하는 함수
export const subscribeToMessages = (callback) => {
    // 생성일 오름차순(오래된 것부터)으로 전체 메시지 조회
    const q = query(collection(db, 'messages'), orderBy('createdAt', 'asc'))

    // onSnapshot: 데이터가 바뀔 때마다 자동으로 callback 실행 (실시간 감지)
    return onSnapshot(q, (snapshot) => {
        const messages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
        callback(messages)
    })
}

// 특정 채팅방의 메시지를 실시간으로 구독하는 함수
// chatRoomId: 채팅방 고유 ID
// callback: 메시지가 바뀔 때마다 호출될 함수
// 반환값: 구독을 해제할 때 호출하는 함수
export const subscribeToChatRoomMessages = (chatRoomId, callback) => {
    // 특정 채팅방 메시지만 시간 오름차순으로 조회
    const q = query(
        collection(db, 'chatRooms', chatRoomId, 'messages'),
        orderBy('createdAt', 'asc')  // 오래된 메시지부터 보이도록 정렬
    )

    // 실시간 감지: 메시지가 추가/변경될 때마다 자동으로 callback 호출
    return onSnapshot(q, (snapshot) => {
        const messages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
        callback(messages)
    })
}

// 채팅방 찾기 또는 생성 함수
// 두 유저 사이에 이미 채팅방이 있으면 기존 채팅방을 반환하고,
// 없으면 새로 만들어서 반환합니다.
// currentUserId: 현재 로그인한 유저 uid
// otherUserId: 상대방 유저 uid
export const findOrCreateChatRoom = async (currentUserId, otherUserId) => {
    // 전체 채팅방을 생성일 오름차순으로 조회
    const q = query(collection(db, 'chatRooms'), orderBy('createdAt', 'asc'))
    const snapshot = await getDocs(q)
    let chatRoom = null

    // 두 유저가 모두 참여한 채팅방이 있는지 확인
    // A→B 로 만든 방과 B→A 로 만든 방 모두 같은 방으로 취급
    snapshot.forEach(doc => {
        const data = doc.data()
        if (
            (data.user1 === currentUserId && data.user2 === otherUserId) ||
            (data.user1 === otherUserId && data.user2 === currentUserId)
        ) {
            chatRoom = { id: doc.id, ...data }
        }
    })

    // 기존 채팅방이 없으면 새로 생성
    if (!chatRoom) {
        const docRef = await addDoc(collection(db, 'chatRooms'), {
            user1: currentUserId,
            user2: otherUserId,
            createdAt: new Date()
        })
        chatRoom = { id: docRef.id, user1: currentUserId, user2: otherUserId, createdAt: new Date() }
    }

    return chatRoom
}
