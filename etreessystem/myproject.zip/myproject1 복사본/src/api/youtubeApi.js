// =============================================
// api/youtubeApi.js - 유튜브 API
// Google YouTube Data API v3를 사용하여
// 영상 검색 및 상세 정보를 가져옵니다.
// API 키는 환경변수(.env 파일)에서 불러옵니다.
// =============================================

const key = import.meta.env.VITE_YOUTUBE_API_KEY  // .env 파일의 YouTube API 키
const baseUrl = 'https://www.googleapis.com/youtube/v3'  // YouTube API 기본 URL

// 유튜브 영상 검색 함수
// query: 검색어 (예: '아이유 노래')
// maxResults=12: 최대 12개 결과 반환
// type=video: 영상만 검색 (채널, 재생목록 제외)
export const fetchYoutubeVideos = async (query) => {
  const response = await fetch(
    `${baseUrl}/search?part=snippet&q=${query}&maxResults=12&type=video&key=${key}`
  )
  const data = await response.json()
  return data.items  // 검색 결과 배열만 반환
}

// 특정 유튜브 영상의 상세 정보 조회 함수
// videoId: 영상 고유 ID (예: 'dQw4w9WgXcQ')
// part=snippet: 제목, 설명, 썸네일 등 기본 정보
// part=contentDetails: 영상 길이 정보
// part=statistics: 조회수, 좋아요 수 등 통계
export const fetchYoutubeVideoDetails = async (videoId) => {
  const response = await fetch(
    `${baseUrl}/videos?part=snippet,contentDetails,statistics&id=${videoId}&key=${key}`
  )
  const data = await response.json()
  return data.items[0]  // 첫 번째(유일한) 결과만 반환
}
