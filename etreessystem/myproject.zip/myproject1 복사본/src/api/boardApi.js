// =============================================
// api/boardApi.js - 게시판 관련 API
// 외부 테스트 서버(JSONPlaceholder)에서
// 가짜 게시판 댓글 데이터를 가져옵니다.
// =============================================

// 게시판 댓글 목록을 가져오는 함수
// JSONPlaceholder는 테스트용 무료 API 서버입니다.
export const fetchComments = async () => {
  const response = await fetch('https://jsonplaceholder.typicode.com/comments')
  const data = await response.json()  // 응답을 JSON 형태로 변환
  return data
}
