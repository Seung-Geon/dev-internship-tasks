// =============================================
// api/dashboardApi.js - 대시보드 통계용 API
// 테스트 서버(JSONPlaceholder)에서 유저/게시글/할일/댓글 데이터를,
// open-meteo에서 날씨 데이터를 가져옵니다.
// =============================================

import axios from "axios";

// 유저 목록 조회
// 반환: 유저 배열 (이름, 이메일, 주소 등)
export const usersApiCall = async () => {
    const response = await axios.get('https://jsonplaceholder.typicode.com/users')
    return response.data
}

// 게시글 목록 조회
// 반환: 게시글 배열 (제목, 내용 등)
export const postsApiCall = async () => {
    const response = await axios.get('https://jsonplaceholder.typicode.com/posts')
    return response.data
}

// 할일(TODO) 목록 조회
// 반환: 할일 배열 (제목, 완료 여부 등)
export const todosApiCall = async () => {
    const response = await axios.get('https://jsonplaceholder.typicode.com/todos')
    return response.data
}

// 댓글 목록 조회
// 반환: 댓글 배열 (이름, 이메일, 내용 등)
export const commentsApiCall = async () => {
    const response = await axios.get('https://jsonplaceholder.typicode.com/comments')
    return response.data
}

// 서울 날씨 데이터 조회 (라인 차트용)
// open-meteo API: 서울(위도 37.5665, 경도 126.9780) 기준
// 최근 7일 + 앞으로의 일별 최고기온 데이터를 가져옵니다.
export const weatherApiCall = async () => {
    const response = await axios.get(
        'https://api.open-meteo.com/v1/forecast?latitude=37.5665&longitude=126.9780&daily=temperature_2m_max&timezone=Asia/Seoul&past_days=7'
    )
    return response
}
