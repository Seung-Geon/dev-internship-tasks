// =============================================
// api/authApi.js - 로그인/회원가입 관련 API
// Firebase Authentication을 사용하여
// 회원가입, 로그인, 로그아웃, 유저 조회 기능을 제공합니다.
// =============================================

import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'firebase/auth'
import { auth } from '../firebase'
import { collection, query, where, getDocs, setDoc, doc } from 'firebase/firestore'
import { db } from '../firebase'

// 회원가입 함수
// email: 이메일 주소, password: 비밀번호
// Firebase에 계정을 만들고, Firestore DB에도 유저 정보를 저장합니다.
export const register = async (email, password) => {
    try {
        // Firebase Auth에 이메일/비밀번호로 계정 생성
        const userCredential = await createUserWithEmailAndPassword(auth, email, password)

        // Firestore 'users' 컬렉션에 유저 정보 문서 저장
        // 문서 ID는 uid(고유 사용자 ID)로 설정
        await setDoc(doc(db, 'users', userCredential.user.uid), {
            uid: userCredential.user.uid,
            email: email,
            createdAt: new Date()  // 가입 시각 기록
        })

        return userCredential.user
    } catch (error) {
        console.error('Error registering user:', error)
        throw error  // 오류를 호출한 곳으로 전달
    }
}

// 로그인 함수
// email과 password로 Firebase에 로그인 요청합니다.
export const login = async (email, password) => {
    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password)
        return userCredential.user  // 로그인한 유저 정보 반환
    } catch (error) {
        console.error('Error logging in:', error)
        throw error
    }
}

// 로그아웃 함수
// 현재 로그인된 계정을 로그아웃 처리합니다.
export const logout = async () => {
    try {
        await signOut(auth)
    } catch (error) {
        console.error('Error logging out:', error)
        throw error
    }
}

// 로그인 상태 변화 감지 함수
// 앱이 실행되는 동안 로그인/로그아웃 상태가 바뀔 때마다
// userRef(콜백 함수)가 자동으로 호출됩니다.
export const onAuthStateChangedListener = (userRef) => {
    onAuthStateChanged(auth, userRef)
}

// 이메일로 유저 정보 조회 함수
// Firestore 'users' 컬렉션에서 이메일이 일치하는 유저를 찾아 반환합니다.
// 없으면 null 반환
export const getUserByEmail = async (email) => {
    const q = query(collection(db, 'users'), where('email', '==', email))
    const snapshot = await getDocs(q)
    if (snapshot.empty) {
        return null  // 해당 이메일의 유저가 없음
    }
    return { id: snapshot.docs[0].id, ...snapshot.docs[0].data() }
}
