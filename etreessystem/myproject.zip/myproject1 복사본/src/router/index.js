// =============================================
// router/index.js - 페이지 라우터 설정
// URL 주소(경로)와 화면(컴포넌트)을 연결합니다.
// 예: '/board' 로 이동하면 Board.vue 화면을 보여줌
// =============================================

import { createRouter, createWebHistory } from 'vue-router'

// 각 페이지 화면 불러오기
import Hello from '../views/Hello.vue'           // 홈 화면
import Board from '../views/Board.vue'           // 게시판 화면
import Weather from '../views/Weather.vue'       // 날씨 화면
import Word from '../views/Word.vue'             // 영단어 사전 화면
import Youtube from '../views/Youtube.vue'       // 유튜브 검색 화면
import YoutubeDetail from '../views/YoutubeDetail.vue' // 유튜브 영상 상세 화면
import Test from '../views/Test.vue'             // 테스트 화면
import LoginView from '../views/LoginView.vue'   // 로그인/회원가입 화면
import ChatView from '../views/ChatView.vue'     // 채팅 목록 화면
import RoomView from '../views/RoomView.vue'     // 채팅방 내부 화면
import DashboardView from '../views/DashboardView.vue' // 대시보드/차트 화면

// URL 경로와 화면 컴포넌트 연결 목록
const routes = [
  { path: '/', component: Hello },                           // 기본 홈 화면
  { path: '/board', component: Board },                      // 게시판
  { path: '/weather', component: Weather },                  // 날씨
  { path: '/word', component: Word },                        // 단어장
  { path: '/youtube', component: Youtube },                  // 유튜브 검색
  { path: '/youtube/:videoId', component: YoutubeDetail },   // 유튜브 상세 (:videoId는 동적 값)
  { path: '/test', component: Test },                        // 테스트
  { path: '/login', component: LoginView },                  // 로그인
  { path: '/chat', component: ChatView },                    // 채팅 메인
  { path: '/chat/:chatRoomId', component: RoomView },        // 채팅방 (:chatRoomId는 방 ID)
  { path: '/chart', component: DashboardView }               // 대시보드/차트
]

// 라우터 생성 (createWebHistory: 주소창에 #없이 일반 URL 사용)
const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
