// =============================================
// stores/weather.js - 날씨 데이터 전역 저장소
// 선택한 도시의 날씨 정보를 관리합니다.
// Weather.vue 화면에서 사용합니다.
// =============================================

import { defineStore } from 'pinia'
import { ref } from 'vue'
import { fetchSeoulWeather } from '../api/weatherApi'

export const useWeatherStore = defineStore('weather', () => {
  // 날씨 데이터 (기온, 습도, 날씨 설명 등)
  const weather = ref(null)

  // 로딩 상태 (API 요청 중이면 true, 완료되면 false)
  const isLoading = ref(false)

  // 특정 도시의 날씨를 가져오는 함수
  // city: 도시 영문명 (예: 'Seoul', 'Busan')
  const getWeather = async (city) => {
    isLoading.value = true           // 로딩 시작
    weather.value = await fetchSeoulWeather(city)  // 날씨 데이터 요청
    isLoading.value = false          // 로딩 완료
  }

  return { weather, isLoading, getWeather }
})
