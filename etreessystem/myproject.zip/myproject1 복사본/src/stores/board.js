// =============================================
// stores/board.js - 게시판 데이터 전역 저장소
// 게시판 목록 데이터를 관리합니다.
// Board.vue 화면에서 사용합니다.
// =============================================

import { defineStore } from 'pinia';
import { reactive } from 'vue';
import { fetchComments } from '../api/boardApi';

export const useBoardStore = defineStore('board', () => {

    // 단일 게시글 정보 (선택된 게시글의 상세 데이터)
    const board = reactive({
        id: 0,
        name: '',
        email: '',
        body: ''
    });

    // 게시판 목록 데이터
    // header: 테이블 컬럼 이름 배열 (예: ['id', 'name', 'email', 'body'])
    // rows: 실제 데이터 행 배열
    const boardList = reactive({
        header: [],
        rows: []
    });

    // 게시판 목록을 API에서 불러오는 함수
    // 첫 번째 항목의 키를 header로 설정하고, 전체 데이터를 rows에 추가합니다.
    const getBoardList = async () => {
        const data = await fetchComments()
        boardList.header = Object.keys(data[0])  // 첫 번째 객체의 키를 컬럼명으로 사용
        boardList.rows.push(...data)              // 전체 데이터를 rows 배열에 추가
    }

    return { board, boardList, getBoardList };
})
