// =============================================
// stores/chat.js - 채팅 메시지 전역 저장소
// 채팅방의 실시간 메시지를 관리합니다.
// RoomView.vue 화면에서 사용합니다.
// =============================================

import { defineStore } from "pinia";
import { subscribeToChatRoomMessages, sendMessage } from '../api/chatApi'
import { ref } from 'vue';

export const useChatStore = defineStore('chat', () => {

    // 현재 채팅방의 메시지 목록 (실시간으로 업데이트됨)
    const messages = ref([])

    // 특정 채팅방의 메시지를 실시간으로 구독하는 함수
    // chatRoomId: 채팅방 고유 ID
    // 반환값: 구독 해제 함수 (화면을 떠날 때 호출해야 메모리 누수 방지)
    const subscribeToMessages = (chatRoomId) => {
        return subscribeToChatRoomMessages(chatRoomId, (newMessages) => {
            messages.value = newMessages  // 새 메시지가 오면 목록 업데이트
        })
    }

    // 메시지를 전송하는 함수
    // chatRoomId: 채팅방 ID
    // userId: 보내는 사람의 고유 ID (uid)
    // senderEmail: 보내는 사람의 이메일
    // content: 메시지 내용
    const sendMessageStore = async (chatRoomId, userId, senderEmail, content) => {
        try {
            await sendMessage({
                chatRoomId,
                text: content,
                uid: userId,
                email: senderEmail,
                createdAt: new Date()  // 전송 시각
            })
        } catch (error) {
            console.error('Error sending message:', error)
        }
    }

    return { messages, subscribeToMessages, sendMessageStore };
})
