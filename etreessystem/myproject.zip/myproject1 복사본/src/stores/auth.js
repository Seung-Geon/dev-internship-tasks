// =============================================
// stores/auth.js - 로그인 상태 전역 저장소
// Pinia를 사용하여 로그인/로그아웃/회원가입 상태를 관리합니다.
// 여러 화면에서 현재 로그인한 유저 정보를 공유할 때 사용합니다.
// =============================================

import { defineStore } from "pinia";
import { reactive, ref } from 'vue';
import { login, onAuthStateChangedListener, logout, register } from "../api/authApi";

export const useAuthStore = defineStore('login', () => {

    // 로그인 입력 폼 데이터 (이메일, 비밀번호)
    const loginInfo = reactive({
        email: '',
        password: ''
    })

    // 현재 로그인한 유저 정보 (로그아웃 상태면 null)
    const user = ref(null)

    // 회원가입 함수
    // email, password를 받아서 Firebase에 새 계정을 만듭니다.
    const registerUser = async (email, password) => {
        try {
            const registeredUser = await register(email, password)
        } catch (error) {
            console.error('Registration error:', error)
        }
    }

    // 로그인 함수
    // 성공하면 user에 로그인한 유저 정보가 저장됩니다.
    const loginUser = async (email, password) => {
        try {
            const loggedInUser = await login(email, password)
            user.value = loggedInUser
        } catch (error) {
            console.error('Login error:', error)
        }
    }

    // 로그아웃 함수
    // 로그아웃 후 user를 null로 초기화합니다.
    const logoutAuth = async () => {
        try {
            await logout()
            user.value = null
        } catch (error) {
            console.error('Logout error:', error)
        }
    }

    // 앱 실행 중 로그인 상태 변화를 자동으로 감지합니다.
    // 예: 다른 탭에서 로그아웃하거나, 페이지를 새로고침해도 로그인 상태 유지
    onAuthStateChangedListener((currentUser) => {
        user.value = currentUser
    })

    return { loginInfo, user, loginUser, logoutAuth, registerUser };
})
