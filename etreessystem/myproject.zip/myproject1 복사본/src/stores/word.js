// =============================================
// stores/word.js - 영어 단어 사전 전역 저장소
// 입력한 영어 단어의 정의(뜻)와 예문을 관리합니다.
// Word.vue 화면에서 사용합니다.
// =============================================

import { ref } from 'vue'
import { defineStore } from 'pinia'
import { fetchWordDefinition, fetchWordExamples } from '../api/wordApi'

export const useWordStore = defineStore('word', () => {

    // 현재 검색한 단어 정보
    // word.word: 검색어 (예: 'apple')
    // word.definitions: 정의/예문 배열 (각 항목에 text 속성 포함)
    const word = ref({
        word: '',
        definitions: []
    })

    // 단어의 정의(뜻)를 조회하는 함수
    // inputWord: 검색할 영어 단어
    const getWordDefinition = async (inputWord) => {
        const data = await fetchWordDefinition(inputWord)
        word.value.word = inputWord      // 검색어 저장
        word.value.definitions = data    // 뜻 목록 저장
    }

    // 단어의 예문을 조회하는 함수
    // inputWord: 검색할 영어 단어
    const getWordExamples = async (inputWord) => {
        const data = await fetchWordExamples(inputWord)
        word.value.word = inputWord
        word.value.definitions = data.examples  // 예문 목록 저장
    }

    return { word, getWordDefinition, getWordExamples }
})
