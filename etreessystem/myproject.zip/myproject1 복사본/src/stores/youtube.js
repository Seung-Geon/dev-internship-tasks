// =============================================
// stores/youtube.js - 유튜브 검색 전역 저장소
// 유튜브 영상 검색 결과를 관리합니다.
// Youtube.vue, YoutubeDetail.vue 화면에서 사용합니다.
// =============================================

import { defineStore } from "pinia";
import { reactive, ref } from "vue";
import { fetchYoutubeVideos, fetchYoutubeVideoDetails } from "../api/youtubeApi";

// 유튜브 API 응답 데이터 구조 예시:
// {
//   "kind": "youtube#searchResult",
//   "id": { "videoId": "XpX-iYrZeZw" },
//   "snippet": {
//     "title": "영상 제목",
//     "description": "영상 설명",
//     "thumbnails": { "high": { "url": "썸네일 이미지 URL" } }
//   }
// }

export const useYoutubeStore = defineStore('youtube', () => {

    // 검색된 유튜브 영상 목록
    const videos = ref([]);

    // 현재 검색어 (검색창에 입력된 텍스트)
    const searchQuery = ref('');

    // 유튜브 영상을 검색하는 함수
    // query: 검색어 (예: '아이유 콘서트')
    const getYoutubeVideos = async (query) => {
        searchQuery.value = query;
        const newVideos = await fetchYoutubeVideos(query);
        videos.value = newVideos;  // 기존 목록을 새 검색 결과로 교체
    }

    // 특정 영상의 상세 정보를 조회하는 함수
    // videoId: 유튜브 영상 고유 ID
    const getYoutubeVideoDetails = async (videoId) => {
        const videoDetails = await fetchYoutubeVideoDetails(videoId);
        return videoDetails;
    }

    // 영상 목록 초기화 함수 (새 검색 전에 기존 결과를 지울 때 사용)
    const clearVideos = () => {
        videos.value = [];
    }

    return { videos, searchQuery, getYoutubeVideos, getYoutubeVideoDetails, clearVideos };
})
