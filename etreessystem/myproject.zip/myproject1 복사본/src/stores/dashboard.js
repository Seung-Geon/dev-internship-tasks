// =============================================
// stores/dashboard.js - 대시보드 차트 데이터 전역 저장소
// 라인 차트와 파이 차트에 사용할 데이터를 관리합니다.
// DashboardView.vue 화면에서 사용합니다.
// =============================================

import { defineStore } from "pinia";
import { reactive, ref } from 'vue';
import { weatherApiCall } from '../api/dashboardApi'

export const useChartStore = defineStore('chart', () => {

    // 라인 차트용 데이터 (ApexCharts 형식: [{name, data}] 배열)
    const series = reactive([])

    // 라인 차트 X축 날짜 목록 (예: ['2026-06-01', '2026-06-02', ...])
    const categorie = ref([])

    // 라인 차트에 추가할 데이터 시리즈 (이름 + 데이터 배열)
    const seriesData = reactive({
        name: '',   // 그래프 이름 (예: 'temperature')
        data: []    // 각 날짜별 값 배열
    })

    // 파이 차트 데이터 (각 조각의 값, 예: [10, 20, 30, 40])
    const pieSeries = ref([])

    // 파이 차트 라벨 (각 조각의 이름, 예: ['유저', '게시글', '댓글', '할일'])
    const pieLabel = ref([])

    // 날씨 API에서 서울의 일별 최고기온 데이터를 가져와서 라인 차트에 설정하는 함수
    const getLineData = async () => {
        // 기존 데이터 초기화
        seriesData.data = []
        categorie.length = 0
        series.length = 0

        const data = await weatherApiCall()

        // X축: 날짜 배열
        categorie.value = data.data.daily.time

        // Y축: 일별 최고기온 배열
        seriesData.name = 'temperature'
        seriesData.data = data.data.daily.temperature_2m_max

        // series 배열에 데이터 추가 (스프레드로 복사 후 추가)
        series.push({ ...seriesData })
    }

    return { series, categorie, seriesData, pieLabel, pieSeries, getLineData };
})
