// =============================================
// stores/user.js - 현재 선택된 유저 정보 전역 저장소
// Hello.vue(테스트 화면)에서 테이블 행 선택 시
// 선택된 유저 정보를 다른 컴포넌트와 공유하기 위해 사용합니다.
// =============================================

import { defineStore } from 'pinia'
import { reactive } from 'vue';

export const useUserStore = defineStore('user', () => {
    // 현재 선택된 유저 정보 (id, name, city 등)
    const user = reactive({});
    return { user };
})
