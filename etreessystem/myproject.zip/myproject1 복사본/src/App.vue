<!-- =============================================
  App.vue - 앱의 기본 틀(레이아웃)
  모든 페이지에 공통으로 보이는 헤더와 사이드 메뉴를 관리합니다.
  실제 페이지 내용은 <RouterView /> 자리에 채워집니다.
============================================= -->
<template>
  <v-app>

    <!-- 상단 헤더 바 -->
    <v-app-bar color="primary" elevation="2">
      <!-- 햄버거 버튼: 클릭하면 사이드 메뉴가 열리고 닫힘 -->
      <v-app-bar-nav-icon @click="drawer = !drawer" />
      <v-app-bar-title>메인배너</v-app-bar-title>
    </v-app-bar>

    <!-- 왼쪽 사이드 메뉴 (drawer: true면 열림, false면 닫힘) -->
    <v-navigation-drawer v-model="drawer">
      <v-list>
        <!-- menuItems 배열을 반복해서 메뉴 항목을 만듦 -->
        <template v-for="item in menuItems" :key="item.title">

          <!-- 하위 메뉴(children)가 없으면 바로 해당 페이지로 이동하는 항목 -->
          <v-list-item
            v-if="!item.children"
            :prepend-icon="item.icon"
            :title="item.title"
            :to="item.path"
          />

          <!-- 하위 메뉴(children)가 있으면 펼쳐지는 그룹으로 표시 -->
          <v-list-group
            v-else
            :value="item.title"
          >
            <template #activator="{ props }">
              <v-list-item
                v-bind="props"
                :prepend-icon="item.icon"
                :title="item.title"
              />
            </template>

            <!-- 하위 메뉴 항목들 (들여쓰기로 구분) -->
            <v-list-item
              v-for="child in item.children"
              :key="child.title"
              :title="child.title"
              :to="child.path"
              class="pl-8"
            />
          </v-list-group>

        </template>
      </v-list>
    </v-navigation-drawer>

    <!-- 메인 콘텐츠 영역: 현재 URL에 맞는 페이지가 여기에 표시됨 -->
    <v-main>
      <v-container>
        <RouterView />
      </v-container>
    </v-main>

  </v-app>
</template>

<script setup>
import { ref } from 'vue'

// 사이드 메뉴 열림/닫힘 상태 (true: 열림)
const drawer = ref(true)

// 사이드 메뉴에 표시될 항목 목록
// title: 메뉴 이름, path: 이동할 URL, icon: 아이콘 이름
const menuItems = ref([
  { title: '홈', path: '/', icon: 'mdi-home' },
  { title: '로그인', path: '/login', icon: 'mdi-login' },
  { title: '게시판', path: '/board', icon: 'mdi-bulletin-board' },
  { title: '날씨', path: '/weather', icon: 'mdi-weather-sunny' },
  { title: '단어장', path: '/word', icon: 'mdi-book-open-variant' },
  { title: '유튜브', path: '/youtube', icon: 'mdi-youtube' },
  { title: '채팅', path: '/chat', icon: 'mdi-chat' },
  { title: '차트', path: '/chart', icon: 'mdi-chart-line' },
  // 아래는 하위 메뉴 예시 (현재 주석 처리됨)
  // { title: '단어장', icon: 'mdi-book-open'
  //   ,children: [
  //   { title: '단어장', path: '/word', icon: 'mdi-book-open-variant' },
  //   ]
  // },
  { title: '테스트', path: '/test', icon: 'mdi-cog' },
  { title: '설정', path: '/setting', icon: 'mdi-cog' },
])
</script>
