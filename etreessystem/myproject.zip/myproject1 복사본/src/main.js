// =============================================
// main.js - 앱 시작점 (가장 처음 실행되는 파일)
// 여기서 Vue 앱을 만들고 필요한 기능들을 연결합니다.
// =============================================

import { createApp } from 'vue'       // Vue 앱을 만드는 함수
import './style.css'                   // 전체 스타일(디자인) 파일
import App from './App.vue'            // 앱의 기본 틀 (모든 화면을 감싸는 껍데기)
import router from './router'          // 페이지 이동을 담당하는 라우터
import { createPinia } from 'pinia'    // 전역 데이터 저장소 (여러 화면에서 공유하는 데이터)
import VueApexCharts from "vue3-apexcharts"; // 차트(그래프) 라이브러리

// Vuetify: 버튼, 카드, 테이블 등 UI 컴포넌트를 제공하는 디자인 라이브러리
import 'vuetify/styles'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'   // 모든 UI 컴포넌트 가져오기
import * as directives from 'vuetify/directives'   // 특수 기능(v-ripple 등) 가져오기
import '@mdi/font/css/materialdesignicons.css'      // 아이콘 폰트 (mdi-home, mdi-chat 같은 아이콘들)

// Vuetify 설정 생성
const vuetify = createVuetify({
  components,
  directives,
})

// Vue 앱 생성 후 모든 기능을 연결하고 '#app' 요소에 화면을 그립니다.
// index.html의 <div id="app"> 안에 앱이 렌더링됩니다.
createApp(App).use(router).use(createPinia()).use(vuetify).use(VueApexCharts).mount('#app')
