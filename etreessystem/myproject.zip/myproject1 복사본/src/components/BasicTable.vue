<!-- =============================================
  BasicTable.vue - 범용 테이블 컴포넌트
  header(컬럼명)와 rows(데이터)를 받아서 테이블을 그립니다.
  체크박스로 행 선택, 행 클릭으로 선택 이벤트, 삭제 버튼 기능을 제공합니다.
  Hello.vue, Board.vue 등에서 재사용합니다.
============================================= -->

<script setup>
import { ref } from 'vue'

// 부모 컴포넌트에서 전달받는 데이터 (props)
defineProps({
  gridData: Object,   // { header: ['컬럼명...'], rows: [{id, ...}, ...] } 형태의 테이블 데이터
  onSelect: Function, // 행(row)을 클릭했을 때 호출할 함수
  selected: Array,    // 현재 선택된 행의 배열
  onRemove: Function  // 삭제 버튼 클릭 시 호출할 함수
})
</script>

<template>
  <!-- 삭제 버튼 -->
  <p><v-btn @click="onRemove">삭제</v-btn></p>

  <!-- 데이터가 있을 때 테이블 표시 -->
  <v-table v-if="gridData.rows.length > 0" border="1" cellpadding="5" cellspacing="0">
    <thead>
      <tr>
        <th></th>       <!-- 체크박스 열 -->
        <th>순번</th>   <!-- 번호 열 -->
        <!-- gridData.header 배열로 컬럼 이름 동적 생성 -->
        <th v-for="header in gridData.header" :key="header">{{ header }}</th>
      </tr>
    </thead>
    <tbody>
      <!-- 각 데이터 행 반복 렌더링 -->
      <tr v-for="(row, index) in gridData.rows" :key="row.id">
        <!-- 체크박스: 선택된 row에 selected 속성 설정 -->
        <td><v-checkbox v-model="row.selected" :value="row.id"/></td>
        <!-- 순번: 클릭 시 onSelect 함수 호출 -->
        <td @click="() => onSelect(row)">{{ index + 1 }}</td>
        <!-- 각 컬럼의 데이터 값 표시 -->
        <td v-for="header in gridData.header" :key="header">
          {{ row[header] }}
        </td>
      </tr>
    </tbody>
  </v-table>

  <!-- 데이터가 없을 때 안내 문구 표시 -->
  <p v-else>데이터가 없습니다.</p>
</template>
