<!-- =============================================
  LineChart.vue - 라인(꺾은선) 차트 컴포넌트
  ApexCharts 라이브러리를 사용하여 라인 차트를 그립니다.
  부모 컴포넌트에서 series(데이터)와 categorie(X축 날짜)를 받습니다.
  DashboardView.vue에서 날씨 기온 변화를 표시하는 데 사용합니다.
============================================= -->

<script setup>
import { computed } from 'vue'

// 부모에서 전달받는 데이터
const props = defineProps({
  series: Array,    // Y축 데이터 배열 (예: [{ name: 'temperature', data: [25, 27, ...] }])
  categorie: Array, // X축 날짜 배열 (예: ['2026-06-01', '2026-06-02', ...])
})

// 차트 옵션: props 값이 바뀔 때마다 자동으로 다시 계산 (computed)
const chartOption = computed(() => ({
  chart: {
    type: 'line',
    toolbar: { show: false }  // 차트 우상단 다운로드 버튼 숨김
  },
  stroke: { curve: 'smooth' },  // 꺾은선을 부드러운 곡선으로 표시
  xaxis: {
    categories: props.categorie  // X축에 날짜 표시
  }
}))
</script>

<template>
  <!-- ApexCharts 라인 차트 렌더링 -->
  <apexchart
    type="line"
    height="350"
    :options="chartOption"
    :series="series"
  />
</template>
