<!-- =============================================
  PieChart.vue - 파이(원형) 차트 컴포넌트
  ApexCharts 라이브러리를 사용하여 파이 차트를 그립니다.
  부모 컴포넌트에서 series(값 배열)와 label(이름 배열)을 받습니다.
  DashboardView.vue에서 유저/게시글/댓글/할일 비율을 표시하는 데 사용합니다.
============================================= -->

<script setup>
import { computed } from "vue"

// 부모에서 전달받는 데이터
const props = defineProps({
    series: Array, // 각 조각의 값 (예: [10, 20, 30, 40])
    label: Array,  // 각 조각의 이름 (예: ['유저', '게시글', '댓글', '할일'])
})

// 차트 옵션: props 값이 바뀔 때마다 자동으로 다시 계산 (computed)
const chartOption = computed(() => ({
    chart: {
        width: 380,
        type: 'pie',
    },
    labels: props.label,  // 각 파이 조각에 표시할 이름
    responsive: [
        {
            // 화면 너비가 480px 이하(모바일)일 때 차트 크기 축소
            breakpoint: 480,
            options: {
                chart: {
                    width: 200,
                },
                legend: {
                    position: 'bottom',  // 범례를 차트 아래에 표시
                },
            },
        },
    ],
}))
</script>

<template>
  <!-- ApexCharts 파이 차트 렌더링 -->
  <apexchart
      type="pie"
      :options="chartOption"
      :series="series"
  ></apexchart>
</template>
