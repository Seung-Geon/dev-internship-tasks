<!-- =============================================
  YoutubeCard.vue - 유튜브 영상 카드 컴포넌트
  유튜브 검색 결과의 영상 하나를 카드 형태로 보여줍니다.
  썸네일 이미지와 제목, 설명을 표시하고,
  클릭하면 해당 영상 상세 페이지로 이동합니다.
  Youtube.vue에서 검색 결과 목록을 표시할 때 사용합니다.
============================================= -->

<script setup>
import { defineProps } from 'vue'
import { RouterLink } from 'vue-router';

// 부모에서 전달받는 영상 데이터
defineProps({
  video: Object  // 유튜브 API의 영상 객체 (id, snippet 포함)
})
</script>

<template>
  <v-card>
    <!-- 클릭 시 유튜브 상세 페이지(/youtube/영상ID)로 이동 -->
    <router-link :to="'/youtube/' + video.id.videoId" target="_self">
      <!-- 영상 썸네일 이미지 -->
      <v-img
        :src="video.snippet.thumbnails.high.url"
        :alt="video.snippet.title"
      />
      <!-- 영상 제목 -->
      <v-card-title>{{ video.snippet.title }}</v-card-title>
    </router-link>
    <!-- 영상 설명 (짧게 표시) -->
    <v-card-subtitle>{{ video.snippet.description }}</v-card-subtitle>
    <v-card-actions>
      <!-- 추후 액션 버튼 추가 가능 -->
    </v-card-actions>
  </v-card>
</template>
