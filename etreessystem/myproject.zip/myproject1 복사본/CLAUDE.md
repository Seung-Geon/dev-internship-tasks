# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

Vue 3 + Vite + Vuetify 학습용 프로젝트. Pinia로 상태 관리, Firebase로 인증/DB, Vuetify로 UI를 구성한다.

## Commands

- `npm run dev` — 개발 서버 실행
- `npm run build` — 프로덕션 빌드
- `npm run preview` — 빌드 결과 미리보기
- 테스트/린트/포맷 스크립트는 아직 없다 (해당 도구 미설치).

## Code style

- **Vue 3 Composition API + `<script setup>`만 사용**한다. Options API(`export default {}`)는 쓰지 않는다.
- **Pinia store는 setup-style**로 작성한다: `defineStore('name', () => { ...refs/functions... })`. options-style(state/getters/actions)은 쓰지 않는다.
- 순수 JavaScript 프로젝트다 (TypeScript 아님, `.ts` 파일이나 `lang="ts"` 없음).
- **주석은 한국어로 작성**한다 — 기존 코드 전반의 관례를 따른다.
- **새 View 파일은 `XxxView.vue` 형식**의 접미사를 붙인다 (기존 `Board.vue`, `Word.vue` 등 접미사 없는 파일은 레거시이며 새로 만들 때는 따르지 않는다).
- `api/*.js`는 Firebase SDK 호출이나 axios 호출을 감싸는 순수 함수로 작성하고, store가 이를 호출해 반응형 상태로 노출하는 패턴을 따른다.

## Environment variables

- `.env`에 `VITE_YOUTUBE_API_KEY`, `VITE_WEATHER_API_KEY`, `VITE_WORDNIK_API_KEY`를 정의한다. `.env.example`에 동일한 키의 빈 템플릿이 있다.
- `src/firebase.js`의 Firebase 웹 config는 현재 소스에 하드코딩되어 있다. 다른 API 키들처럼 `.env`의 `VITE_*` 변수로 옮기는 것을 권장한다 — 새로 Firebase 설정을 건드릴 일이 있으면 이 방식으로 통일할 것.
- `.env`는 절대 커밋하지 않는다 (`.gitignore`에 이미 포함됨).

## Notes

- 이 저장소는 아직 git 저장소로 초기화되어 있지 않다.
- 테스트/린트 도구가 없으므로 변경 후 검증은 `npm run dev`로 직접 동작을 확인하는 방식에 의존한다.
